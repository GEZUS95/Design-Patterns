﻿namespace Assignment2
{
    interface IPencilSharpener
    {
        void Sharpen(IPencil pencil);
    }
}
