﻿namespace Opgave4.Interfaces
{
    public interface IAlarmController
    {
        void ActiveerAlarm(string melding);
    }
}
