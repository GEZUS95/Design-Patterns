﻿namespace Opgave2
{
    public interface IProcessor
    {
        void Execute(string program);
    }
}