﻿namespace assignment1
{
    public class CheapMonitor : IMonitor
    {
        public void Display()
        {
            System.Console.WriteLine("displaying stuff very poor...");        }
    }
}