﻿namespace assignment1
{
    public class CheapProcessor : IProcessor
    {
        public void PerformOperation()
        {
            System.Console.WriteLine("performing operation not so quickly...");        }
    }
}