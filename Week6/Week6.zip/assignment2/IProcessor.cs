﻿namespace assignment2
{
    public interface IProcessor
    {
        void PerformOperation();
    }
}