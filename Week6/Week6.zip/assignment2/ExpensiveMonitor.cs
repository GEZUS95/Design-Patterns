﻿namespace assignment2
{
    public class ExpensiveMonitor : IMonitor
    {
        public void Display()
        {
            System.Console.WriteLine("displaying stuff very nice...");
        }
    }
}