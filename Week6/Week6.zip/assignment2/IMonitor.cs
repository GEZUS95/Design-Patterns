﻿namespace assignment2
{
    public interface IMonitor
    {
        void Display();
    }
}