﻿using assignment1.Controller.Interfaces;
using assignment1.Model;
using assignment1.Model.Interfaces;
using assignment1.View.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment1.Controller
{
    public class TrainController : ITrainController
    {
        private ITrainJourney _trainJourney;

        public TrainController(ITrainJourney trainJourney)
        {
            this._trainJourney = trainJourney;
        }

        public void NextStation()
        {
            _trainJourney.NextStation();
        }


        
    }
}
