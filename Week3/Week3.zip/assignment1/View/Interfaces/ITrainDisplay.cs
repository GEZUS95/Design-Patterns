﻿using assignment1.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment1.View.Interfaces
{
    public interface ITrainDisplay
    {
        void Update(TrainStation station);
    }
}
