﻿
namespace assignment1
{
    public class King : Character
    {
        public King()
        {
            Weapon = new BowAndArrowBehaviour();
        }
    }
}
