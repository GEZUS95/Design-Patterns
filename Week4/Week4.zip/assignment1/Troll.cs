﻿namespace assignment1
{
    public class Troll : Character
    {
        public Troll()
        {
            Weapon = new AxeBehaviour();
        }
    }
}
