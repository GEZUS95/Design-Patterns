﻿namespace assignment1
{
    public class Knight : Character
    {
        public Knight()
        {
            Weapon = new SwordBehavior();
        }
    }
}
