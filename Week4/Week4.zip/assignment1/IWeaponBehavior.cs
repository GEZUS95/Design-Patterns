﻿namespace assignment1
{
    public interface IWeaponBehavior
    {
        void UseWeapon();
    }
}