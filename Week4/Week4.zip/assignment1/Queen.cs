﻿namespace assignment1
{
    public class Queen : Character
    {
        public Queen()
        {
            Weapon = new KnifeBehaviour();
        }
    }
}
